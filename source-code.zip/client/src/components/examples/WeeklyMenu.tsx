import WeeklyMenu from '../WeeklyMenu';

export default function WeeklyMenuExample() {
  return <WeeklyMenu />;
}
