import SurveySection from '../SurveySection';

export default function SurveySectionExample() {
  return <SurveySection />;
}
