import FeedbackForm from '../FeedbackForm';

export default function FeedbackFormExample() {
  return <FeedbackForm />;
}
